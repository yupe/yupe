<?php
 return array (
  'class' => 'CDbConnection',
  'connectionString' => 'mysql:host=localhost;dbname=yupe',
  'username' => 'root',
  'password' => 'root',
  'emulatePrepare' => true,
  'charset' => 'utf8',
  'enableParamLogging' => 1,
  'enableProfiling' => 1,
  'schemaCachingDuration' => 108000,
  'tablePrefix' => '',
) ;
?>